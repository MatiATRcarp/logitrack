<?php
class UsuarioModel {

    public function __construct(private PDO $pdo) {}

    public function registrar(
        string $dni,
        string $nombre,
        string $apellido,
        string $email,
        string $password,
        string $rol,
        array  $extra = []
    ): string {
        $rolesValidos = $this->pdo->query("SELECT nombre FROM rol")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array($rol, $rolesValidos, true)) {
            throw new InvalidArgumentException('Rol inválido.');
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);

        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO usuario (dni, email, nombre, apellido, password_hash, id_rol)
                VALUES (:dni, :email, :nombre, :apellido, :hash, :id_rol)
            ");
            $stmt->execute([
                ':dni'      => $dni,
                ':email'    => $email,
                ':nombre'   => $nombre,
                ':apellido' => $apellido,
                ':hash'     => $hash,
                ':id_rol'   => $rol,
            ]);

            if ($rol === 'chofer') {
                $chk = $this->pdo->prepare("SELECT 1 FROM chofer WHERE dni = :dni");
                $chk->execute([':dni' => $dni]);
                if (!$chk->fetch()) {
                    $stmt2 = $this->pdo->prepare("
                        INSERT INTO chofer (dni, nombre, apellido, email, legajo, tipo_licencia)
                        VALUES (:dni, :nombre, :apellido, :email, :legajo, :licencia)
                    ");
                    $stmt2->execute([
                        ':dni'      => $dni,
                        ':nombre'   => $nombre,
                        ':apellido' => $apellido,
                        ':email'    => $email,
                        ':legajo'   => $extra['legajo'],
                        ':licencia' => $extra['tipo_licencia'],
                    ]);
                }
            } elseif ($rol === 'cliente') {
                $chk = $this->pdo->prepare("SELECT 1 FROM cliente WHERE dni = :dni");
                $chk->execute([':dni' => $dni]);
                if (!$chk->fetch()) {
                    $stmt2 = $this->pdo->prepare("
                        INSERT INTO cliente (dni, nombre, apellido, email, direccion, activo)
                        VALUES (:dni, :nombre, :apellido, :email, :direccion, 1)
                    ");
                    $stmt2->execute([
                        ':dni'       => $dni,
                        ':nombre'    => $nombre,
                        ':apellido'  => $apellido,
                        ':email'     => $email,
                        ':direccion' => $extra['direccion'] ?? null,
                    ]);
                }
            } elseif ($rol === 'empleado') {
                $chk = $this->pdo->prepare("SELECT 1 FROM empleado WHERE dni = :dni");
                $chk->execute([':dni' => $dni]);
                if (!$chk->fetch()) {
                    // Generate next legajo before insert (legajo is now the PK)
                    $maxRow = $this->pdo->query(
                        "SELECT COALESCE(MAX(CAST(SUBSTRING(legajo, 4) AS UNSIGNED)), 0) FROM empleado WHERE legajo REGEXP '^EMP[0-9]+$'"
                    )->fetchColumn();
                    $legajo = 'EMP' . str_pad((string) ((int)$maxRow + 1), 4, '0', STR_PAD_LEFT);

                    $stmt2 = $this->pdo->prepare("
                        INSERT INTO empleado (legajo, dni, nombre, apellido, id_sucursal)
                        VALUES (:legajo, :dni, :nombre, :apellido, :suc)
                    ");
                    $stmt2->execute([
                        ':legajo'   => $legajo,
                        ':dni'      => $dni,
                        ':nombre'   => $nombre,
                        ':apellido' => $apellido,
                        ':suc'      => $extra['id_sucursal'],
                    ]);

                    // Sync legajo into usuario.id_empleado
                    $this->pdo->prepare("UPDATE usuario SET id_empleado = :leg WHERE dni = :dni")
                        ->execute([':leg' => $legajo, ':dni' => $dni]);
                }
            }

            $this->pdo->commit();
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            throw $e;
        }

        return $dni;
    }

    public function buscarPorDniEmail(string $dni, string $email): array|false {
        $stmt = $this->pdo->prepare("
            SELECT dni AS id_usuario, nombre
            FROM   usuario
            WHERE  dni = :dni AND email = :email
            LIMIT  1
        ");
        $stmt->execute([':dni' => $dni, ':email' => $email]);
        return $stmt->fetch();
    }

    public function actualizarPassword(string $dni, string $email, string $password): void {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $this->pdo->prepare("UPDATE usuario SET password_hash = :hash WHERE dni = :dni AND email = :email")
            ->execute([':hash' => $hash, ':dni' => $dni, ':email' => $email]);
    }
}
