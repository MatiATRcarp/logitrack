<?php
class EnvioModel {

    public function __construct(private PDO $pdo) {}

    public function getFormData(): array {
        return [
            'tipos_contenido' => $this->pdo->query(
                "SELECT nombre AS id_tipo_cont, nombre FROM tipo_contenido ORDER BY nombre"
            )->fetchAll(),
            'sucursales' => $this->pdo->query(
                "SELECT nombre AS id_sucursal, nombre FROM sucursal ORDER BY nombre"
            )->fetchAll(),
            'clientes' => $this->pdo->query(
                "SELECT dni AS id_cliente, dni, nombre, apellido FROM cliente ORDER BY apellido"
            )->fetchAll(),
        ];
    }

    public function crear(array $data): string {
        $nro_tracking = 'TRK-' . strtoupper(substr(md5(uniqid((string) rand(), true)), 0, 8));

        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO envio
                    (nro_tracking, fecha_recepcion, peso_kg, id_tipo_cont,
                     id_remitente, id_destinatario, id_suc_origen, id_suc_destino)
                VALUES
                    (:nro, NOW(), :peso, :tipo, :rem, :dest, :orig, :destino)
            ");
            $stmt->execute([
                ':nro'     => $nro_tracking,
                ':peso'    => $data['peso_kg'],
                ':tipo'    => $data['id_tipo_cont'],
                ':rem'     => $data['id_remitente'],
                ':dest'    => $data['id_destinatario'],
                ':orig'    => $data['id_suc_origen'],
                ':destino' => $data['id_suc_destino'],
            ]);

            $this->pdo->prepare("
                INSERT INTO historial_estado (id_envio, id_estado, fecha_hora, id_sucursal_actual)
                VALUES (:envio, 'Pendiente', NOW(), :suc)
            ")->execute([':envio' => $nro_tracking, ':suc' => $data['id_suc_origen']]);

            $this->pdo->commit();
            return $nro_tracking;

        } catch (PDOException $e) {
            $this->pdo->rollBack();
            error_log("EnvioModel::crear — " . $e->getMessage());
            throw $e;
        }
    }

    public function confirmarRecepcion(string $nroTracking, string $idSucursalActual): bool {
        $stmt = $this->pdo->prepare("
            SELECT id_estado FROM historial_estado
            WHERE id_envio = :nro_tracking
            ORDER BY id_hist DESC
            LIMIT 1
        ");
        $stmt->execute([':nro_tracking' => $nroTracking]);
        $ultimo = $stmt->fetch();

        if (!$ultimo || !in_array($ultimo['id_estado'], ['En tránsito', 'Ingresado en sucursal destino'])) {
            throw new \RuntimeException(
                'El envío no está en un estado que permita confirmar la recepción (debe ser En tránsito o En sucursal destino).'
            );
        }

        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO historial_estado (id_envio, id_estado, fecha_hora, id_sucursal_actual)
                VALUES (:nro_tracking, 'Entregado', NOW(), :id_sucursal)
            ");
            $stmt->bindValue(':nro_tracking', $nroTracking,      PDO::PARAM_STR);
            $stmt->bindValue(':id_sucursal',  $idSucursalActual, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("EnvioModel::confirmarRecepcion — " . $e->getMessage());
            throw $e;
        }
    }
}
