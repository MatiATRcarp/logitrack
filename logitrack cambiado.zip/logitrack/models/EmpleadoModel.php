<?php
class EmpleadoModel {

    public function __construct(private PDO $pdo) {}

    public function getPdo(): PDO { return $this->pdo; }

    public function getEnviosPendientes(?string $id_sucursal, int $limite = 50): array {
        $filtro = $id_sucursal ? "AND e.id_suc_origen = :suc" : "";

        $stmt = $this->pdo->prepare("
            SELECT e.nro_tracking, e.peso_kg,
                   tc.nombre AS tipo_contenido,
                   c_rem.nombre  AS remitente,  c_rem.apellido  AS rem_apellido,
                   c_dest.nombre AS destinatario, c_dest.apellido AS dest_apellido,
                   s_dest.nombre AS sucursal_destino,
                   he.id_estado AS estado, he.fecha_hora
            FROM   envio e
            JOIN   tipo_contenido   tc     ON e.id_tipo_cont    = tc.nombre
            JOIN   cliente          c_rem  ON e.id_remitente    = c_rem.dni
            JOIN   cliente          c_dest ON e.id_destinatario = c_dest.dni
            JOIN   sucursal         s_dest ON e.id_suc_destino  = s_dest.nombre
            JOIN   historial_estado he     ON he.id_hist = (
                SELECT MAX(h2.id_hist) FROM historial_estado h2 WHERE h2.id_envio = e.nro_tracking
            )
            WHERE  he.id_estado = 'Pendiente'
            $filtro
            ORDER  BY he.fecha_hora DESC
            LIMIT  :limite
        ");

        if ($id_sucursal) {
            $stmt->bindValue(':suc', $id_sucursal, PDO::PARAM_STR);
        }
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getViajesHoy(): int {
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(*) AS c FROM viaje WHERE DATE(fecha_salida) = CURDATE()"
        );
        $stmt->execute();
        return (int) $stmt->fetch()['c'];
    }

    public function getEnviosEnAlmacenOrigen(): array {
        $stmt = $this->pdo->query("
            SELECT e.nro_tracking, e.peso_kg,
                   tc.nombre AS tipo_contenido,
                   CONCAT(cd.nombre, ' ', cd.apellido) AS destinatario,
                   so.nombre AS sucursal_origen,
                   sd.nombre AS sucursal_destino
            FROM   envio e
            JOIN   tipo_contenido tc ON e.id_tipo_cont    = tc.nombre
            JOIN   cliente  cd ON e.id_destinatario = cd.dni
            JOIN   sucursal so ON e.id_suc_origen   = so.nombre
            JOIN   sucursal sd ON e.id_suc_destino  = sd.nombre
            JOIN   historial_estado he ON he.id_hist = (
                SELECT MAX(h2.id_hist) FROM historial_estado h2 WHERE h2.id_envio = e.nro_tracking
            )
            WHERE  he.id_estado = 'Pendiente'
            ORDER  BY e.fecha_recepcion DESC
        ");
        return $stmt->fetchAll();
    }

    public function getPesoTotalEnvios(array $nros_tracking): float {
        if (empty($nros_tracking)) {
            return 0.0;
        }
        $placeholders = implode(',', array_fill(0, count($nros_tracking), '?'));
        $stmt = $this->pdo->prepare(
            "SELECT COALESCE(SUM(peso_kg), 0) AS total FROM envio WHERE nro_tracking IN ($placeholders)"
        );
        $stmt->execute($nros_tracking);
        return (float) $stmt->fetch()['total'];
    }

    public function getVehiculo(string $patente): array|false {
        $stmt = $this->pdo->prepare("
            SELECT v.patente, tv.capacidad_kg_max, tv.requiere_licencia_especial
            FROM   vehiculo v
            JOIN   tipo_vehiculo tv ON v.id_tipo_veh = tv.nombre
            WHERE  v.patente = :patente
        ");
        $stmt->execute([':patente' => $patente]);
        return $stmt->fetch();
    }

    public function getChofer(string $id_chofer): array|false {
        $stmt = $this->pdo->prepare("SELECT dni, tipo_licencia FROM chofer WHERE dni = :id");
        $stmt->execute([':id' => $id_chofer]);
        return $stmt->fetch();
    }

    public function crearViajeConEnvios(array $data): int {
        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO viaje (fecha_salida, fecha_llegada_est, patente, id_chofer)
                VALUES (:salida, :llegada, :patente, :chofer)
            ");
            $stmt->execute([
                ':salida'  => $data['fecha_salida'],
                ':llegada' => $data['fecha_llegada_est'],
                ':patente' => $data['patente'],
                ':chofer'  => $data['id_chofer'],
            ]);
            $id_viaje = (int) $this->pdo->lastInsertId();

            $stmtViajeEnvio = $this->pdo->prepare(
                "INSERT INTO viaje_envio (id_viaje, id_envio) VALUES (:viaje, :envio)"
            );
            $stmtSucOrigen = $this->pdo->prepare(
                "SELECT id_suc_origen FROM envio WHERE nro_tracking = :nro"
            );
            $stmtHistorial = $this->pdo->prepare("
                INSERT INTO historial_estado (id_envio, id_estado, fecha_hora, id_sucursal_actual)
                VALUES (:envio, 'En tránsito', NOW(), :suc)
            ");

            foreach ($data['envios'] as $nro_tracking) {
                $stmtViajeEnvio->execute([':viaje' => $id_viaje, ':envio' => $nro_tracking]);

                $stmtSucOrigen->execute([':nro' => $nro_tracking]);
                $id_suc_origen = $stmtSucOrigen->fetchColumn();

                $stmtHistorial->execute([':envio' => $nro_tracking, ':suc' => $id_suc_origen]);
            }

            $this->pdo->commit();
            return $id_viaje;

        } catch (PDOException $e) {
            $this->pdo->rollBack();
            error_log("EmpleadoModel::crearViajeConEnvios — " . $e->getMessage());
            throw $e;
        }
    }
}
