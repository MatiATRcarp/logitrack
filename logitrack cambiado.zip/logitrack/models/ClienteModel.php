<?php
class ClienteModel {

    public function __construct(private PDO $pdo) {}

    public function getPerfil(string $usuario_dni): array|false {
        $stmt = $this->pdo->prepare("
            SELECT c.dni AS id_cliente, c.nombre, c.apellido, c.dni
            FROM   cliente c
            JOIN   usuario u ON c.dni = u.dni
            WHERE  u.dni = :dni LIMIT 1
        ");
        $stmt->execute([':dni' => $usuario_dni]);
        return $stmt->fetch();
    }

    public function getEnviados(string $usuario_dni, int $limite = 50): array {
        $stmt = $this->pdo->prepare("
            SELECT e.nro_tracking, e.peso_kg, e.fecha_recepcion,
                   c_dest.nombre AS dest_nombre, c_dest.apellido AS dest_apellido,
                   s_dest.nombre AS sucursal_destino,
                   he.id_estado  AS estado,
                   EXISTS(SELECT 1 FROM viaje_envio ve WHERE ve.id_envio = e.nro_tracking) AS en_viaje
            FROM   envio e
            JOIN   cliente  c_dest  ON e.id_destinatario = c_dest.dni
            JOIN   sucursal s_dest  ON e.id_suc_destino  = s_dest.nombre
            JOIN   historial_estado he ON he.id_hist = (
                SELECT MAX(h2.id_hist) FROM historial_estado h2 WHERE h2.id_envio = e.nro_tracking
            )
            WHERE  e.id_remitente = :usuario_dni
              AND  he.id_estado != 'Cancelado'
            ORDER  BY e.fecha_recepcion DESC
            LIMIT  :limite
        ");
        $stmt->bindValue(':usuario_dni', $usuario_dni, PDO::PARAM_STR);
        $stmt->bindValue(':limite',      $limite,      PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function cancelarEnvio(string $nroTracking, string $usuarioDni): array {
        $stmt = $this->pdo->prepare("
            SELECT e.nro_tracking, e.id_suc_origen
            FROM   envio e
            JOIN   historial_estado he ON he.id_hist = (
                SELECT MAX(h2.id_hist) FROM historial_estado h2 WHERE h2.id_envio = e.nro_tracking
            )
            WHERE  e.nro_tracking = :nro
              AND  e.id_remitente = :dni
              AND  he.id_estado   = 'Pendiente'
            LIMIT  1
        ");
        $stmt->execute([':nro' => $nroTracking, ':dni' => $usuarioDni]);
        $envio = $stmt->fetch();

        if (!$envio) {
            return ['ok' => false, 'mensaje' => 'No se puede cancelar: el envío no existe, no te pertenece, o ya no está en estado Pendiente.'];
        }

        $stmt2 = $this->pdo->prepare("SELECT COUNT(*) FROM viaje_envio WHERE id_envio = :nro");
        $stmt2->execute([':nro' => $nroTracking]);
        if ((int) $stmt2->fetchColumn() > 0) {
            return ['ok' => false, 'mensaje' => 'No se puede cancelar: el envío ya fue asignado a un viaje en curso.'];
        }

        $this->pdo->prepare("
            INSERT INTO historial_estado (id_envio, id_estado, fecha_hora, id_sucursal_actual)
            VALUES (:nro, 'Cancelado', NOW(), :suc)
        ")->execute([':nro' => $nroTracking, ':suc' => $envio['id_suc_origen']]);

        return ['ok' => true, 'mensaje' => "El envío $nroTracking fue cancelado correctamente."];
    }

    public function getARecibir(string $usuario_dni): array {
        $stmt = $this->pdo->prepare("
            SELECT e.nro_tracking, e.peso_kg,
                   c_rem.nombre AS rem_nombre, c_rem.apellido AS rem_apellido,
                   s_orig.nombre AS sucursal_origen,
                   s_dest.nombre AS sucursal_destino,
                   he.id_estado  AS estado, he.fecha_hora AS ultimo_evento
            FROM   envio e
            JOIN   cliente  c_rem   ON e.id_remitente   = c_rem.dni
            JOIN   sucursal s_orig  ON e.id_suc_origen  = s_orig.nombre
            JOIN   sucursal s_dest  ON e.id_suc_destino = s_dest.nombre
            JOIN   historial_estado he ON he.id_hist = (
                SELECT MAX(h2.id_hist) FROM historial_estado h2 WHERE h2.id_envio = e.nro_tracking
            )
            WHERE  e.id_destinatario = :usuario_dni
            AND    he.id_estado NOT IN ('Entregado', 'Cancelado', 'Devuelto al remitente')
            ORDER  BY he.fecha_hora DESC
        ");
        $stmt->execute([':usuario_dni' => $usuario_dni]);
        return $stmt->fetchAll();
    }
}
