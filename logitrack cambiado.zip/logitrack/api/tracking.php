<?php
// api/tracking.php — Endpoint JSON: posición en tiempo real de viajes activos
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

$filtrarCliente = isset($_GET['cliente']) && $_GET['cliente'] === '1';
$filtrarChofer  = isset($_GET['chofer'])  && $_GET['chofer']  === '1';

if ($filtrarCliente && $_SESSION['usuario_rol'] !== 'cliente') {
    http_response_code(403);
    echo json_encode(['error' => 'Acceso denegado']);
    exit;
}
if ($filtrarChofer && $_SESSION['usuario_rol'] !== 'chofer') {
    http_response_code(403);
    echo json_encode(['error' => 'Acceso denegado']);
    exit;
}

// Roles sin acceso al endpoint completo
$rolesPermitidos = ['admin', 'empleado', 'chofer', 'cliente'];
if (!in_array($_SESSION['usuario_rol'], $rolesPermitidos)) {
    http_response_code(403);
    echo json_encode(['error' => 'Acceso denegado']);
    exit;
}

try {
    // Subquery: toma el id_envio mínimo por viaje para evitar GROUP BY ambiguo
    // con ONLY_FULL_GROUP_BY de MySQL 5.7+
    $sql = "
        SELECT
            v.id_viaje,
            v.fecha_salida,
            v.fecha_llegada_est,
            v.patente,
            CONCAT(ch.nombre, ' ', ch.apellido)   AS chofer,
            so.nombre                              AS sucursal_origen,
            so.latitud                             AS lat_origen,
            so.longitud                            AS lng_origen,
            sd.nombre                              AS sucursal_destino,
            sd.latitud                             AS lat_destino,
            sd.longitud                            AS lng_destino,
            (SELECT COUNT(*) FROM viaje_envio vc WHERE vc.id_viaje = v.id_viaje) AS total_paquetes
        FROM viaje v
        JOIN chofer ch ON v.id_chofer = ch.dni
        JOIN (
            SELECT id_viaje, MIN(id_envio) AS nro_tracking
            FROM   viaje_envio
            GROUP  BY id_viaje
        ) primer_envio ON primer_envio.id_viaje = v.id_viaje
        JOIN envio    e  ON e.nro_tracking     = primer_envio.nro_tracking
        JOIN sucursal so ON e.id_suc_origen    = so.nombre
        JOIN sucursal sd ON e.id_suc_destino   = sd.nombre
        WHERE v.fecha_salida <= NOW()
          AND (v.fecha_llegada_est >= DATE_SUB(NOW(), INTERVAL 1 DAY) OR v.fecha_llegada_est IS NULL)
          AND NOT EXISTS (
              SELECT 1 FROM historial_estado he2
              JOIN   viaje_envio ve2 ON he2.id_envio = ve2.id_envio
              WHERE  ve2.id_viaje = v.id_viaje
                AND  he2.id_estado = 'Entregado'
          )
    ";

    $params = [];

    if ($filtrarCliente) {
        $sql .= " AND e.id_destinatario = :usuario_id ";
        $params[':usuario_id'] = $_SESSION['usuario_id'];
    }
    if ($filtrarChofer) {
        $sql .= " AND v.id_chofer = :usuario_id ";
        $params[':usuario_id'] = $_SESSION['usuario_id'];
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $viajes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $resultado = [];
    foreach ($viajes as $v) {
        $salida       = strtotime($v['fecha_salida']);
        $llegada      = $v['fecha_llegada_est'] ? strtotime($v['fecha_llegada_est']) : null;
        $ahora        = time();
        $duracion     = ($llegada !== null) ? ($llegada - $salida) : 0;
        $transcurrido = $ahora - $salida;
        $progreso     = $duracion > 0 ? min(1, max(0, $transcurrido / $duracion)) : 0;

        $hasCoords = $v['lat_origen'] !== null && $v['lat_destino'] !== null
                  && $v['lng_origen'] !== null && $v['lng_destino'] !== null;

        if ($hasCoords) {
            $lat_actual = (float) $v['lat_origen'] + ((float) $v['lat_destino'] - (float) $v['lat_origen']) * $progreso;
            $lng_actual = (float) $v['lng_origen'] + ((float) $v['lng_destino'] - (float) $v['lng_origen']) * $progreso;
        } else {
            $lat_actual = null;
            $lng_actual = null;
        }

        $resultado[] = [
            'id_viaje'          => (int)  $v['id_viaje'],
            'patente'           =>         $v['patente'],
            'chofer'            =>         $v['chofer'],
            'sucursal_origen'   =>         $v['sucursal_origen'],
            'sucursal_destino'  =>         $v['sucursal_destino'],
            'lat_actual'        => $lat_actual !== null ? round($lat_actual, 6) : null,
            'lng_actual'        => $lng_actual !== null ? round($lng_actual, 6) : null,
            'lat_origen'        => $v['lat_origen']  !== null ? (float) $v['lat_origen']  : null,
            'lng_origen'        => $v['lng_origen']  !== null ? (float) $v['lng_origen']  : null,
            'lat_destino'       => $v['lat_destino'] !== null ? (float) $v['lat_destino'] : null,
            'lng_destino'       => $v['lng_destino'] !== null ? (float) $v['lng_destino'] : null,
            'tiene_coords'      => $hasCoords,
            'progreso_pct'      => round($progreso * 100, 1),
            'total_paquetes'    => (int)  $v['total_paquetes'],
            'fecha_salida'      =>         $v['fecha_salida'],
            'fecha_llegada_est' =>         $v['fecha_llegada_est'],
        ];
    }

    echo json_encode($resultado);

} catch (PDOException $e) {
    error_log("api/tracking.php — " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Error interno del servidor']);
}
