-- ══════════════════════════════════════════════════════════════════════════════
-- migration_natural_pk.sql
-- Migra 6 tablas de PK artificial INT a clave natural.
-- Ejecutar en phpMyAdmin, bloque por bloque.
-- Verificar el SELECT al final de cada bloque antes de continuar con el siguiente.
-- ══════════════════════════════════════════════════════════════════════════════

USE dblogitrack;

-- ─────────────────────────────────────────────────────────────────────────────
-- BLOQUE 1 de 6: rol
-- PK: id_rol INT → nombre VARCHAR(50)
-- Hijo: usuario.id_rol INT → VARCHAR(50) con el nombre del rol
-- ─────────────────────────────────────────────────────────────────────────────

SET FOREIGN_KEY_CHECKS = 0;

-- Agregar columna temporal en usuario
ALTER TABLE usuario ADD COLUMN _id_rol_new VARCHAR(50) DEFAULT NULL;

-- Poblar desde rol.nombre
UPDATE usuario u JOIN rol r ON u.id_rol = r.id_rol SET u._id_rol_new = r.nombre;

-- Reemplazar columna
ALTER TABLE usuario DROP COLUMN id_rol;
ALTER TABLE usuario RENAME COLUMN _id_rol_new TO id_rol;

-- Quitar UNIQUE de rol.nombre (si existe) antes de promoverla a PK
SET @_idx = (
    SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'rol'
      AND COLUMN_NAME = 'nombre' AND NON_UNIQUE = 0 AND INDEX_NAME != 'PRIMARY'
    LIMIT 1
);
SET @_sql = IF(@_idx IS NOT NULL, CONCAT('ALTER TABLE rol DROP INDEX `', @_idx, '`'), 'SELECT 1');
PREPARE _s FROM @_sql; EXECUTE _s; DEALLOCATE PREPARE _s;

-- Migrar PK de rol
ALTER TABLE rol MODIFY COLUMN id_rol INT NOT NULL;
ALTER TABLE rol DROP PRIMARY KEY;
ALTER TABLE rol DROP COLUMN id_rol;
ALTER TABLE rol ADD PRIMARY KEY (nombre);

SET FOREIGN_KEY_CHECKS = 1;

-- Re-agregar FK
ALTER TABLE usuario ADD CONSTRAINT fk_usuario_rol
    FOREIGN KEY (id_rol) REFERENCES rol(nombre);

-- Verificación BLOQUE 1
-- Esperado: 0 (ningún usuario quedó sin rol)
SELECT COUNT(*) AS usuario_sin_rol FROM usuario WHERE id_rol IS NULL;


-- ─────────────────────────────────────────────────────────────────────────────
-- BLOQUE 2 de 6: tipo_estado
-- PK: id_estado INT → nombre VARCHAR(50)
-- Hijo: historial_estado.id_estado INT → VARCHAR(50) con el nombre del estado
-- ─────────────────────────────────────────────────────────────────────────────

SET FOREIGN_KEY_CHECKS = 0;

-- Agregar columna temporal en historial_estado
ALTER TABLE historial_estado ADD COLUMN _id_estado_new VARCHAR(50) DEFAULT NULL;

-- Poblar desde tipo_estado.nombre
UPDATE historial_estado h
    JOIN tipo_estado t ON h.id_estado = t.id_estado
    SET h._id_estado_new = t.nombre;

-- Reemplazar columna
ALTER TABLE historial_estado DROP COLUMN id_estado;
ALTER TABLE historial_estado RENAME COLUMN _id_estado_new TO id_estado;

-- Quitar UNIQUE de tipo_estado.nombre si existe
SET @_idx = (
    SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tipo_estado'
      AND COLUMN_NAME = 'nombre' AND NON_UNIQUE = 0 AND INDEX_NAME != 'PRIMARY'
    LIMIT 1
);
SET @_sql = IF(@_idx IS NOT NULL, CONCAT('ALTER TABLE tipo_estado DROP INDEX `', @_idx, '`'), 'SELECT 1');
PREPARE _s FROM @_sql; EXECUTE _s; DEALLOCATE PREPARE _s;

-- Migrar PK de tipo_estado
ALTER TABLE tipo_estado MODIFY COLUMN id_estado INT NOT NULL;
ALTER TABLE tipo_estado DROP PRIMARY KEY;
ALTER TABLE tipo_estado DROP COLUMN id_estado;
ALTER TABLE tipo_estado ADD PRIMARY KEY (nombre);

SET FOREIGN_KEY_CHECKS = 1;

-- Re-agregar FK
ALTER TABLE historial_estado ADD CONSTRAINT fk_hist_tipo_estado
    FOREIGN KEY (id_estado) REFERENCES tipo_estado(nombre);

-- Verificación BLOQUE 2
-- Esperado: 0 (ningún historial quedó sin estado)
SELECT COUNT(*) AS historial_sin_estado FROM historial_estado WHERE id_estado IS NULL;


-- ─────────────────────────────────────────────────────────────────────────────
-- BLOQUE 3 de 6: provincia
-- PK: id_provincia INT → nombre VARCHAR(50)
-- Hijo: localidad.id_provincia INT → nombre_provincia VARCHAR(50)
-- (Sin impacto PHP — columnas nunca referenciadas en el código)
-- ─────────────────────────────────────────────────────────────────────────────

SET FOREIGN_KEY_CHECKS = 0;

-- Agregar columna nueva en localidad
ALTER TABLE localidad ADD COLUMN nombre_provincia VARCHAR(50) DEFAULT NULL;

-- Poblar desde provincia.nombre
UPDATE localidad l JOIN provincia p ON l.id_provincia = p.id_provincia
    SET l.nombre_provincia = p.nombre;

-- Quitar columna vieja
ALTER TABLE localidad DROP COLUMN id_provincia;

-- Quitar UNIQUE de provincia.nombre si existe
SET @_idx = (
    SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'provincia'
      AND COLUMN_NAME = 'nombre' AND NON_UNIQUE = 0 AND INDEX_NAME != 'PRIMARY'
    LIMIT 1
);
SET @_sql = IF(@_idx IS NOT NULL, CONCAT('ALTER TABLE provincia DROP INDEX `', @_idx, '`'), 'SELECT 1');
PREPARE _s FROM @_sql; EXECUTE _s; DEALLOCATE PREPARE _s;

-- Migrar PK de provincia
ALTER TABLE provincia MODIFY COLUMN id_provincia INT NOT NULL;
ALTER TABLE provincia DROP PRIMARY KEY;
ALTER TABLE provincia DROP COLUMN id_provincia;
ALTER TABLE provincia ADD PRIMARY KEY (nombre);

SET FOREIGN_KEY_CHECKS = 1;

-- Re-agregar FK
ALTER TABLE localidad ADD CONSTRAINT fk_localidad_provincia
    FOREIGN KEY (nombre_provincia) REFERENCES provincia(nombre);

-- Verificación BLOQUE 3
-- Esperado: 0
SELECT COUNT(*) AS localidad_sin_provincia FROM localidad WHERE nombre_provincia IS NULL;


-- ─────────────────────────────────────────────────────────────────────────────
-- BLOQUE 4 de 6: localidad
-- PK: id_localidad INT → (nombre, nombre_provincia) composite
-- Hijos: sucursal.id_localidad → (nombre_localidad, nombre_provincia)
--        cliente.id_localidad  → (nombre_localidad, nombre_provincia)
-- NOTA: Si sucursal o cliente no tienen columna id_localidad, omitir esas sub-secciones.
-- ─────────────────────────────────────────────────────────────────────────────

SET FOREIGN_KEY_CHECKS = 0;

-- sucursal: agregar columnas y poblar
ALTER TABLE sucursal
    ADD COLUMN nombre_localidad VARCHAR(100) DEFAULT NULL,
    ADD COLUMN nombre_provincia VARCHAR(50)  DEFAULT NULL;

UPDATE sucursal s
    JOIN localidad l ON s.id_localidad = l.id_localidad
    SET s.nombre_localidad = l.nombre,
        s.nombre_provincia = l.nombre_provincia;

ALTER TABLE sucursal DROP COLUMN id_localidad;

-- cliente: agregar columnas y poblar
ALTER TABLE cliente
    ADD COLUMN nombre_localidad VARCHAR(100) DEFAULT NULL,
    ADD COLUMN nombre_provincia VARCHAR(50)  DEFAULT NULL;

UPDATE cliente c
    JOIN localidad l ON c.id_localidad = l.id_localidad
    SET c.nombre_localidad = l.nombre,
        c.nombre_provincia = l.nombre_provincia;

ALTER TABLE cliente DROP COLUMN id_localidad;

-- Migrar PK de localidad
ALTER TABLE localidad MODIFY COLUMN id_localidad INT NOT NULL;
ALTER TABLE localidad DROP PRIMARY KEY;
ALTER TABLE localidad DROP COLUMN id_localidad;
ALTER TABLE localidad ADD PRIMARY KEY (nombre, nombre_provincia);

SET FOREIGN_KEY_CHECKS = 1;

-- Re-agregar FKs
ALTER TABLE sucursal ADD CONSTRAINT fk_sucursal_localidad
    FOREIGN KEY (nombre_localidad, nombre_provincia) REFERENCES localidad(nombre, nombre_provincia);
ALTER TABLE cliente ADD CONSTRAINT fk_cliente_localidad
    FOREIGN KEY (nombre_localidad, nombre_provincia) REFERENCES localidad(nombre, nombre_provincia);

-- Verificación BLOQUE 4
-- Esperado: 0 en ambos
SELECT COUNT(*) AS suc_sin_localidad FROM sucursal WHERE nombre_localidad IS NULL;
SELECT COUNT(*) AS cli_sin_localidad FROM cliente  WHERE nombre_localidad IS NULL;


-- ─────────────────────────────────────────────────────────────────────────────
-- BLOQUE 5 de 6: sucursal
-- PK: id_sucursal INT → nombre VARCHAR(150)
-- Hijos: empleado.id_sucursal        INT → VARCHAR(150)
--        vehiculo.id_sucursal         INT → VARCHAR(150)
--        envio.id_suc_origen          INT → VARCHAR(150)
--        envio.id_suc_destino         INT → VARCHAR(150)
--        historial_estado.id_sucursal_actual INT → VARCHAR(150) NULL
-- ─────────────────────────────────────────────────────────────────────────────

SET FOREIGN_KEY_CHECKS = 0;

-- empleado
ALTER TABLE empleado ADD COLUMN _suc_new VARCHAR(150) DEFAULT NULL;
UPDATE empleado e JOIN sucursal s ON e.id_sucursal = s.id_sucursal SET e._suc_new = s.nombre;
ALTER TABLE empleado DROP COLUMN id_sucursal;
ALTER TABLE empleado RENAME COLUMN _suc_new TO id_sucursal;

-- vehiculo
ALTER TABLE vehiculo ADD COLUMN _suc_new VARCHAR(150) DEFAULT NULL;
UPDATE vehiculo v JOIN sucursal s ON v.id_sucursal = s.id_sucursal SET v._suc_new = s.nombre;
ALTER TABLE vehiculo DROP COLUMN id_sucursal;
ALTER TABLE vehiculo RENAME COLUMN _suc_new TO id_sucursal;

-- envio: id_suc_origen
ALTER TABLE envio ADD COLUMN _suc_orig_new VARCHAR(150) DEFAULT NULL;
UPDATE envio e JOIN sucursal s ON e.id_suc_origen = s.id_sucursal SET e._suc_orig_new = s.nombre;
ALTER TABLE envio DROP COLUMN id_suc_origen;
ALTER TABLE envio RENAME COLUMN _suc_orig_new TO id_suc_origen;

-- envio: id_suc_destino
ALTER TABLE envio ADD COLUMN _suc_dest_new VARCHAR(150) DEFAULT NULL;
UPDATE envio e JOIN sucursal s ON e.id_suc_destino = s.id_sucursal SET e._suc_dest_new = s.nombre;
ALTER TABLE envio DROP COLUMN id_suc_destino;
ALTER TABLE envio RENAME COLUMN _suc_dest_new TO id_suc_destino;

-- historial_estado: id_sucursal_actual (se permite NULL)
ALTER TABLE historial_estado ADD COLUMN _suc_act_new VARCHAR(150) DEFAULT NULL;
UPDATE historial_estado h
    JOIN sucursal s ON h.id_sucursal_actual = s.id_sucursal
    SET h._suc_act_new = s.nombre;
ALTER TABLE historial_estado DROP COLUMN id_sucursal_actual;
ALTER TABLE historial_estado RENAME COLUMN _suc_act_new TO id_sucursal_actual;

-- Quitar UNIQUE de sucursal.nombre si existe
SET @_idx = (
    SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sucursal'
      AND COLUMN_NAME = 'nombre' AND NON_UNIQUE = 0 AND INDEX_NAME != 'PRIMARY'
    LIMIT 1
);
SET @_sql = IF(@_idx IS NOT NULL, CONCAT('ALTER TABLE sucursal DROP INDEX `', @_idx, '`'), 'SELECT 1');
PREPARE _s FROM @_sql; EXECUTE _s; DEALLOCATE PREPARE _s;

-- Migrar PK de sucursal
ALTER TABLE sucursal MODIFY COLUMN id_sucursal INT NOT NULL;
ALTER TABLE sucursal DROP PRIMARY KEY;
ALTER TABLE sucursal DROP COLUMN id_sucursal;
ALTER TABLE sucursal ADD PRIMARY KEY (nombre);

SET FOREIGN_KEY_CHECKS = 1;

-- Re-agregar FKs hacia sucursal
ALTER TABLE empleado ADD CONSTRAINT fk_empleado_sucursal
    FOREIGN KEY (id_sucursal) REFERENCES sucursal(nombre);
ALTER TABLE vehiculo ADD CONSTRAINT fk_vehiculo_sucursal
    FOREIGN KEY (id_sucursal) REFERENCES sucursal(nombre);
ALTER TABLE envio ADD CONSTRAINT fk_envio_suc_origen
    FOREIGN KEY (id_suc_origen) REFERENCES sucursal(nombre);
ALTER TABLE envio ADD CONSTRAINT fk_envio_suc_destino
    FOREIGN KEY (id_suc_destino) REFERENCES sucursal(nombre);
ALTER TABLE historial_estado ADD CONSTRAINT fk_hist_sucursal
    FOREIGN KEY (id_sucursal_actual) REFERENCES sucursal(nombre);

-- Verificación BLOQUE 5
-- Esperado: 0 en todos (no deben existir filas con FK vacía en tablas que siempre tuvieron valor)
SELECT COUNT(*) AS emp_sin_suc FROM empleado WHERE id_sucursal IS NULL;
SELECT COUNT(*) AS veh_sin_suc FROM vehiculo WHERE id_sucursal IS NULL;
SELECT COUNT(*) AS env_sin_orig FROM envio WHERE id_suc_origen IS NULL;
SELECT COUNT(*) AS env_sin_dest FROM envio WHERE id_suc_destino IS NULL;

-- IMPORTANTE: Después de este bloque, volver a ejecutar sql/sp_operaciones.sql
-- para recrear los stored procedures con los tipos de variable actualizados.


-- ─────────────────────────────────────────────────────────────────────────────
-- BLOQUE 6 de 6: empleado
-- PK: id_empleado INT → legajo VARCHAR(20)
-- Hijo: usuario.id_empleado INT → VARCHAR(20) con el legajo
-- ─────────────────────────────────────────────────────────────────────────────

SET FOREIGN_KEY_CHECKS = 0;

-- Quitar FK de usuario.id_empleado si existe
SET @_fk = (
    SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'usuario'
      AND COLUMN_NAME = 'id_empleado' AND REFERENCED_TABLE_NAME IS NOT NULL
    LIMIT 1
);
SET @_sql = IF(@_fk IS NOT NULL, CONCAT('ALTER TABLE usuario DROP FOREIGN KEY `', @_fk, '`'), 'SELECT 1');
PREPARE _s FROM @_sql; EXECUTE _s; DEALLOCATE PREPARE _s;

-- Poblar usuario.id_empleado con el legajo
ALTER TABLE usuario ADD COLUMN _emp_new VARCHAR(20) DEFAULT NULL;
UPDATE usuario u JOIN empleado e ON u.dni = e.dni SET u._emp_new = e.legajo;
ALTER TABLE usuario DROP COLUMN id_empleado;
ALTER TABLE usuario RENAME COLUMN _emp_new TO id_empleado;

-- Quitar UNIQUE de empleado.legajo si existe
SET @_idx = (
    SELECT INDEX_NAME FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'empleado'
      AND COLUMN_NAME = 'legajo' AND NON_UNIQUE = 0 AND INDEX_NAME != 'PRIMARY'
    LIMIT 1
);
SET @_sql = IF(@_idx IS NOT NULL, CONCAT('ALTER TABLE empleado DROP INDEX `', @_idx, '`'), 'SELECT 1');
PREPARE _s FROM @_sql; EXECUTE _s; DEALLOCATE PREPARE _s;

-- Migrar PK de empleado
ALTER TABLE empleado MODIFY COLUMN id_empleado INT NOT NULL;
ALTER TABLE empleado DROP PRIMARY KEY;
ALTER TABLE empleado DROP COLUMN id_empleado;
ALTER TABLE empleado ADD PRIMARY KEY (legajo);

SET FOREIGN_KEY_CHECKS = 1;

-- Re-agregar FK
ALTER TABLE usuario ADD CONSTRAINT fk_usuario_empleado
    FOREIGN KEY (id_empleado) REFERENCES empleado(legajo);

-- Verificación BLOQUE 6
-- Esperado: 0 (todos los usuarios-empleado tienen legajo)
SELECT COUNT(*) AS emp_usuario_sin_legajo
FROM usuario u JOIN empleado e ON u.dni = e.dni
WHERE u.id_empleado IS NULL;

-- ══════════════════════════════════════════════════════════════════════════════
-- FIN DE LA MIGRACIÓN
-- Recordar:
--   1. Verificar que todos los SELECT de verificación devuelvan 0.
--   2. Re-ejecutar sql/sp_operaciones.sql (DROP+CREATE de los 3 stored procedures).
--   3. Los PHP ya están actualizados — no se requieren cambios adicionales en ellos.
-- ══════════════════════════════════════════════════════════════════════════════
