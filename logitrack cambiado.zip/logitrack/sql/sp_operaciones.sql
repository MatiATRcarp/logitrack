-- =====================================================================
-- sp_operaciones.sql
-- Procedimientos operacionales: armar viaje, finalizar viaje,
-- registrar incidente.
-- Ejecutar ONCE en phpMyAdmin (base de datos: dblogitrack).
-- =====================================================================

USE dblogitrack;

-- ── Prerequisitos de esquema ─────────────────────────────────────────

-- Permitir NULL en el zombie id_envio (resuelve "Column id_envio cannot be null")
ALTER TABLE envio MODIFY id_envio INT DEFAULT NULL;

-- Columnas nuevas en viaje
ALTER TABLE viaje
  ADD COLUMN finalizado       TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN fecha_finalizado DATETIME            DEFAULT NULL;

-- confirmado_por en historial_estado
ALTER TABLE historial_estado
  ADD COLUMN confirmado_por VARCHAR(20) DEFAULT NULL;

-- dni_chofer en incidente
ALTER TABLE incidente
  ADD COLUMN dni_chofer VARCHAR(15) DEFAULT NULL;

-- Estado "Con incidencias" (si no existe)
INSERT IGNORE INTO tipo_estado (nombre) VALUES ('Con incidencias');

-- ── sp_armar_viaje ────────────────────────────────────────────────────
-- Crea un viaje asignando envíos, validando peso y licencia.
-- p_envios_csv: nro_tracking separados por coma, sin espacios.
-- Devuelve: id_viaje INT.

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_armar_viaje$$
CREATE PROCEDURE sp_armar_viaje(
    IN p_dni_chofer   VARCHAR(15),
    IN p_patente      VARCHAR(20),
    IN p_envios_csv   TEXT,
    IN p_fecha_salida DATETIME,
    IN p_fecha_llegada DATETIME
)
BEGIN
    DECLARE v_cap_max       DECIMAL(10,2);
    DECLARE v_req_esp       TINYINT(1);
    DECLARE v_licencia      VARCHAR(30);
    DECLARE v_peso_total    DECIMAL(10,2);
    DECLARE v_id_estado_tr  INT;
    DECLARE v_id_viaje      INT;
    DECLARE v_nro           VARCHAR(30);
    DECLARE v_suc_orig      INT;
    DECLARE v_idx           INT DEFAULT 1;
    DECLARE v_total_parts   INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Vehículo
    SET v_cap_max = NULL;
    SELECT tv.capacidad_kg_max, tv.requiere_licencia_especial
    INTO   v_cap_max, v_req_esp
    FROM   vehiculo v
    JOIN   tipo_vehiculo tv ON v.id_tipo_veh = tv.nombre
    WHERE  v.patente = p_patente
    LIMIT  1;

    IF v_cap_max IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Vehículo no encontrado o sin tipo asignado.';
    END IF;

    -- Peso total
    SELECT COALESCE(SUM(peso_kg), 0)
    INTO   v_peso_total
    FROM   envio
    WHERE  FIND_IN_SET(nro_tracking, p_envios_csv) > 0;

    IF v_peso_total > v_cap_max THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = CONCAT(
                'Peso total (', ROUND(v_peso_total, 2),
                ' kg) supera la capacidad del vehículo (',
                ROUND(v_cap_max, 2), ' kg).'
            );
    END IF;

    -- Licencia
    SET v_licencia = NULL;
    SELECT tipo_licencia INTO v_licencia
    FROM   chofer WHERE dni = p_dni_chofer LIMIT 1;

    IF v_licencia IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Chofer no encontrado.';
    END IF;

    IF v_req_esp = 1 AND v_licencia NOT IN ('E1','E2','E3','C2') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = CONCAT(
                'Licencia insuficiente: vehículo requiere especial, chofer tiene ',
                v_licencia, '.'
            );
    END IF;

    -- Estado "En tránsito"
    SELECT id_estado INTO v_id_estado_tr
    FROM   tipo_estado WHERE nombre = 'En tránsito' LIMIT 1;

    -- Transacción
    START TRANSACTION;

    INSERT INTO viaje (fecha_salida, fecha_llegada_est, patente, id_chofer, finalizado)
    VALUES (p_fecha_salida, p_fecha_llegada, p_patente, p_dni_chofer, 0);

    SET v_id_viaje    = LAST_INSERT_ID();
    SET v_total_parts = LENGTH(p_envios_csv)
                        - LENGTH(REPLACE(p_envios_csv, ',', '')) + 1;

    WHILE v_idx <= v_total_parts DO
        SET v_nro = TRIM(SUBSTRING_INDEX(
                        SUBSTRING_INDEX(p_envios_csv, ',', v_idx),
                        ',', -1));

        IF v_nro != '' THEN
            INSERT INTO viaje_envio (id_viaje, id_envio)
            VALUES (v_id_viaje, v_nro);

            SELECT id_suc_origen INTO v_suc_orig
            FROM   envio WHERE nro_tracking = v_nro LIMIT 1;

            INSERT INTO historial_estado
                (id_envio, id_estado, fecha_hora, id_sucursal_actual, confirmado_por)
            VALUES
                (v_nro, v_id_estado_tr, NOW(), v_suc_orig, 'sistema');
        END IF;

        SET v_idx = v_idx + 1;
    END WHILE;

    COMMIT;

    SELECT v_id_viaje AS id_viaje;
END$$


-- ── sp_finalizar_viaje ────────────────────────────────────────────────
-- Marca el viaje como finalizado e inserta "Ingresado en sucursal destino"
-- para cada envío del viaje que no esté ya entregado o cancelado.

DROP PROCEDURE IF EXISTS sp_finalizar_viaje$$
CREATE PROCEDURE sp_finalizar_viaje(
    IN p_id_viaje   INT,
    IN p_dni_chofer VARCHAR(15)
)
BEGIN
    DECLARE v_chofer_db  VARCHAR(15);
    DECLARE v_finalizado TINYINT(1) DEFAULT 0;
    DECLARE v_nro_envio  VARCHAR(30);
    DECLARE v_suc_dest   INT;
    DECLARE v_id_estado  INT;
    DECLARE v_cerrado    INT;
    DECLARE v_done       BOOLEAN DEFAULT FALSE;

    DECLARE cur_envios CURSOR FOR
        SELECT ve.id_envio, e.id_suc_destino
        FROM   viaje_envio ve
        JOIN   envio e ON ve.id_envio = e.nro_tracking
        WHERE  ve.id_viaje = p_id_viaje;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Verificar propiedad
    SET v_chofer_db = NULL;
    SELECT id_chofer, COALESCE(finalizado, 0)
    INTO   v_chofer_db, v_finalizado
    FROM   viaje WHERE id_viaje = p_id_viaje LIMIT 1;

    IF v_chofer_db IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Viaje no encontrado.';
    END IF;
    IF v_chofer_db != p_dni_chofer THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Acceso denegado: este viaje no te pertenece.';
    END IF;
    IF v_finalizado = 1 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'El viaje ya fue finalizado anteriormente.';
    END IF;

    SELECT id_estado INTO v_id_estado
    FROM   tipo_estado WHERE nombre = 'Ingresado en sucursal destino' LIMIT 1;

    START TRANSACTION;

    UPDATE viaje
    SET    finalizado = 1, fecha_finalizado = NOW()
    WHERE  id_viaje = p_id_viaje;

    OPEN cur_envios;
    envios_loop: LOOP
        FETCH cur_envios INTO v_nro_envio, v_suc_dest;
        IF v_done THEN LEAVE envios_loop; END IF;

        -- Saltar si ya tiene estado terminal
        SELECT COUNT(*) INTO v_cerrado
        FROM   historial_estado he
        JOIN   tipo_estado te ON he.id_estado = te.id_estado
        WHERE  he.id_envio = v_nro_envio
          AND  te.nombre IN ('Entregado', 'Cancelado');

        IF v_cerrado = 0 THEN
            INSERT INTO historial_estado
                (id_envio, id_estado, fecha_hora, id_sucursal_actual, confirmado_por)
            VALUES
                (v_nro_envio, v_id_estado, NOW(), v_suc_dest, 'chofer');
        END IF;
    END LOOP envios_loop;
    CLOSE cur_envios;

    COMMIT;
END$$


-- ── sp_registrar_incidente ────────────────────────────────────────────
-- Inserta el incidente y, si es Accidente o Robo, registra
-- "Con incidencias" en el historial de todos los envíos del viaje.

DROP PROCEDURE IF EXISTS sp_registrar_incidente$$
CREATE PROCEDURE sp_registrar_incidente(
    IN p_id_viaje       INT,
    IN p_tipo_incidente VARCHAR(50),
    IN p_descripcion    VARCHAR(200),
    IN p_dni_chofer     VARCHAR(15)
)
BEGIN
    DECLARE v_chofer_db  VARCHAR(15);
    DECLARE v_nro_envio  VARCHAR(30);
    DECLARE v_suc_actual INT;
    DECLARE v_id_estado  INT;
    DECLARE v_done       BOOLEAN DEFAULT FALSE;

    DECLARE cur_envios CURSOR FOR
        SELECT ve.id_envio,
               (SELECT MAX(h.id_sucursal_actual)
                FROM   historial_estado h
                WHERE  h.id_envio = ve.id_envio) AS suc_actual
        FROM   viaje_envio ve
        WHERE  ve.id_viaje = p_id_viaje;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Verificar propiedad
    SET v_chofer_db = NULL;
    SELECT id_chofer INTO v_chofer_db
    FROM   viaje WHERE id_viaje = p_id_viaje LIMIT 1;

    IF v_chofer_db IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Viaje no encontrado.';
    END IF;
    IF v_chofer_db != p_dni_chofer THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Acceso denegado: este viaje no te pertenece.';
    END IF;

    START TRANSACTION;

    INSERT INTO incidente (id_viaje, tipo_incidente, descripcion, fecha_hora, dni_chofer)
    VALUES (p_id_viaje, p_tipo_incidente, p_descripcion, NOW(), p_dni_chofer);

    IF p_tipo_incidente IN ('Accidente', 'Robo') THEN
        SELECT id_estado INTO v_id_estado
        FROM   tipo_estado WHERE nombre = 'Con incidencias' LIMIT 1;

        OPEN cur_envios;
        inc_loop: LOOP
            FETCH cur_envios INTO v_nro_envio, v_suc_actual;
            IF v_done THEN LEAVE inc_loop; END IF;

            INSERT INTO historial_estado
                (id_envio, id_estado, fecha_hora, id_sucursal_actual, confirmado_por)
            VALUES
                (v_nro_envio, v_id_estado, NOW(), COALESCE(v_suc_actual, 1), 'sistema');
        END LOOP inc_loop;
        CLOSE cur_envios;
    END IF;

    COMMIT;
END$$

DELIMITER ;

-- =====================================================================
-- Instrucciones de uso desde PHP:
--
-- SP1:  CALL sp_armar_viaje('20123456', 'ABC123', 'TRK-AA,TRK-BB',
--             '2026-07-01 08:00:00', '2026-07-05 18:00:00')
--       → SELECT id_viaje (capturar con fetch())
--
-- SP2:  CALL sp_finalizar_viaje(42, '20123456')
--       → sin resultado; SIGNAL en error
--
-- SP3:  CALL sp_registrar_incidente(42, 'Robo',
--             'Descripción del evento', '20123456')
--       → sin resultado; SIGNAL en error
-- =====================================================================
