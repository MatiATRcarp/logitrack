<?php
require_once __DIR__ . '/../models/ClienteModel.php';
require_once __DIR__ . '/../models/EnvioModel.php';

class ClienteController {

    private ClienteModel $model;
    private EnvioModel   $envioModel;
    private PDO          $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo        = $pdo;
        $this->model      = new ClienteModel($pdo);
        $this->envioModel = new EnvioModel($pdo);
    }

    public function getPerfil(string $usuario_dni): array|false {
        return $this->model->getPerfil($usuario_dni);
    }

    public function getDashboardData(string $usuario_dni): array {
        $cliente  = $this->model->getPerfil($usuario_dni);
        $enviados = [];

        if ($cliente) {
            $enviados = $this->model->getEnviados($usuario_dni);
        }

        return [
            'cliente'  => $cliente,
            'enviados' => $enviados,
        ];
    }

    public function getFormData(): array {
        return $this->envioModel->getFormData();
    }

    public function solicitarEnvio(string $id_cliente, array $post): array {
        $id_destinatario = trim($post['id_destinatario'] ?? '');
        $id_tipo_cont    = trim($post['id_tipo_cont']    ?? '');
        $id_suc_origen   = (int) ($post['id_suc_origen']   ?? 0);
        $id_suc_destino  = (int) ($post['id_suc_destino']  ?? 0);
        $peso_kg         = filter_var($post['peso_kg'] ?? '', FILTER_VALIDATE_FLOAT);

        $errores = [];
        if (empty($id_destinatario))                    $errores[] = 'Seleccioná el destinatario.';
        if ($id_destinatario === $id_cliente)           $errores[] = 'No podés enviarte a vos mismo.';
        if (empty($id_tipo_cont))                       $errores[] = 'Seleccioná el tipo de contenido.';
        if ($id_suc_origen === 0)                       $errores[] = 'Seleccioná la sucursal de origen.';
        if ($id_suc_destino === 0)                      $errores[] = 'Seleccioná la sucursal de destino.';
        if ($id_suc_origen === $id_suc_destino)         $errores[] = 'Origen y destino no pueden ser la misma sucursal.';
        if ($peso_kg === false || $peso_kg <= 0)        $errores[] = 'El peso debe ser un número positivo.';

        if (!empty($errores)) {
            return ['ok' => false, 'mensaje' => implode(' ', $errores)];
        }

        try {
            $nro = $this->envioModel->crear([
                'id_remitente'    => $id_cliente,
                'id_destinatario' => $id_destinatario,
                'id_tipo_cont'    => $id_tipo_cont,
                'id_suc_origen'   => $id_suc_origen,
                'id_suc_destino'  => $id_suc_destino,
                'peso_kg'         => $peso_kg,
            ]);
            return ['ok' => true, 'nro_tracking' => $nro, 'mensaje' => "Envío registrado. Tracking: $nro"];
        } catch (PDOException $e) {
            error_log("ClienteController::solicitarEnvio — " . $e->getMessage());
            return ['ok' => false, 'mensaje' => 'Error al registrar el envío. Intentá nuevamente.'];
        }
    }

    public function cancelarEnvio(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /logitrack/views/cliente/dashboard.php');
            exit;
        }

        $nroTracking = trim($_POST['nro_tracking'] ?? '');
        if (empty($nroTracking)) {
            $_SESSION['flash_msg']  = 'Número de tracking inválido.';
            $_SESSION['flash_tipo'] = 'error';
            header('Location: /logitrack/views/cliente/dashboard.php');
            exit;
        }

        $result = $this->model->cancelarEnvio($nroTracking, $_SESSION['usuario_id']);
        $_SESSION['flash_msg']  = $result['mensaje'];
        $_SESSION['flash_tipo'] = $result['ok'] ? 'success' : 'error';
        header('Location: /logitrack/views/cliente/dashboard.php');
        exit;
    }

    public function confirmarRecepcion(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /logitrack/views/cliente/a_recibir.php');
            exit;
        }

        $nroTracking = trim($_POST['id_envio'] ?? '');
        if (empty($nroTracking)) {
            header('Location: /logitrack/views/cliente/a_recibir.php?error=' . urlencode('Número de tracking inválido.'));
            exit;
        }

        // Verificar que el envío pertenece al cliente logueado (es el destinatario)
        $stmt = $this->pdo->prepare("
            SELECT e.nro_tracking, e.id_suc_destino
            FROM   envio   e
            JOIN   cliente c  ON e.id_destinatario = c.dni
            JOIN   usuario u  ON c.dni             = u.dni
            WHERE  e.nro_tracking = :nro_tracking
              AND  u.dni          = :usuario_dni
            LIMIT  1
        ");
        $stmt->bindValue(':nro_tracking', $nroTracking,                  PDO::PARAM_STR);
        $stmt->bindValue(':usuario_dni',  $_SESSION['usuario_id'],        PDO::PARAM_STR);
        $stmt->execute();
        $envio = $stmt->fetch();

        if (!$envio) {
            header('Location: /logitrack/views/cliente/a_recibir.php?error=' . urlencode('No tenés permiso para confirmar este envío.'));
            exit;
        }

        try {
            $this->envioModel->confirmarRecepcion($nroTracking, (int) $envio['id_suc_destino']);
            header('Location: /logitrack/views/cliente/a_recibir.php?ok=' . urlencode('¡Recepción confirmada correctamente!'));
        } catch (\Exception $e) {
            error_log("ClienteController::confirmarRecepcion — " . $e->getMessage());
            header('Location: /logitrack/views/cliente/a_recibir.php?error=' . urlencode($e->getMessage()));
        }
        exit;
    }
}

// ─── Punto de entrada directo (POST desde formularios) ────────────────────────
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'])) {
    require_once __DIR__ . '/../config/db.php';
    require_once __DIR__ . '/../middleware/auth.php';
    requireRol(['cliente']);

    $ctrl   = new ClienteController($pdo);
    $action = $_GET['action'] ?? '';

    if ($action === 'confirmarRecepcion') {
        $ctrl->confirmarRecepcion();
    } elseif ($action === 'cancelarEnvio') {
        $ctrl->cancelarEnvio();
    } else {
        header('Location: /logitrack/views/cliente/a_recibir.php');
        exit;
    }
}
