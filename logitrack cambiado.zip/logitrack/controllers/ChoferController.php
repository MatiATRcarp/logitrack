<?php
require_once __DIR__ . '/../models/ChoferModel.php';
require_once __DIR__ . '/../models/IncidenteModel.php';
require_once __DIR__ . '/../models/EnvioModel.php';

class ChoferController {

    private ChoferModel    $choferModel;
    private IncidenteModel $incidenteModel;
    private EnvioModel     $envioModel;
    private PDO            $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo            = $pdo;
        $this->choferModel    = new ChoferModel($pdo);
        $this->incidenteModel = new IncidenteModel($pdo);
        $this->envioModel     = new EnvioModel($pdo);
    }

    public function getDashboardData(string $usuario_dni): array {
        $chofer       = $this->choferModel->getPerfil($usuario_dni);
        $viaje_activo = null;
        $envios_carga = [];

        if ($chofer) {
            $viaje_activo = $this->choferModel->getViajeActivo($chofer['id_chofer']);
            if ($viaje_activo) {
                $envios_carga = $this->choferModel->getCargaViaje($viaje_activo['id_viaje']);
            }
        }

        return [
            'chofer'       => $chofer,
            'viaje_activo' => $viaje_activo,
            'envios_carga' => $envios_carga,
        ];
    }

    public function getPerfilData(string $usuario_dni): array {
        $chofer = $this->choferModel->getPerfil($usuario_dni);
        $viajes = $chofer ? $this->choferModel->getViajesRealizados($chofer['id_chofer']) : [];

        return [
            'chofer' => $chofer,
            'viajes' => $viajes,
        ];
    }

    public function reportarIncidente(int $id_viaje, array $post): array {
        $tipo        = trim($post['tipo_incidente'] ?? '');
        $descripcion = trim($post['descripcion']    ?? '');
        $dni_chofer  = $_SESSION['usuario_id'] ?? '';

        if (empty($tipo) || empty($descripcion)) {
            return ['ok' => false, 'mensaje' => 'Completá todos los campos.'];
        }
        if (strlen($descripcion) > 200) {
            return ['ok' => false, 'mensaje' => 'La descripción no puede superar 200 caracteres.'];
        }

        try {
            $stmt = $this->pdo->prepare("CALL sp_registrar_incidente(?, ?, ?, ?)");
            $stmt->execute([$id_viaje, $tipo, $descripcion, $dni_chofer]);
            $stmt->closeCursor();
            return ['ok' => true, 'mensaje' => 'Incidente reportado correctamente.'];
        } catch (PDOException $e) {
            $msg = $e->errorInfo[2] ?? $e->getMessage();
            error_log("sp_registrar_incidente — " . $e->getMessage());
            if ($e->getCode() === '45000') {
                return ['ok' => false, 'mensaje' => $msg];
            }
            return ['ok' => false, 'mensaje' => 'Error al guardar el incidente.'];
        }
    }

    public function finalizarViaje(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /logitrack/views/chofer/dashboard.php');
            exit;
        }

        $id_viaje   = (int) ($_POST['id_viaje'] ?? 0);
        $dni_chofer = $_SESSION['usuario_id'] ?? '';

        if ($id_viaje <= 0) {
            header('Location: /logitrack/views/chofer/dashboard.php?error=' . urlencode('ID de viaje inválido.'));
            exit;
        }

        try {
            $stmt = $this->pdo->prepare("CALL sp_finalizar_viaje(?, ?)");
            $stmt->execute([$id_viaje, $dni_chofer]);
            $stmt->closeCursor();
            header('Location: /logitrack/views/chofer/dashboard.php?ok=' . urlencode("Viaje #{$id_viaje} finalizado. Los envíos quedaron registrados en sucursal destino."));
        } catch (PDOException $e) {
            $msg = $e->getCode() === '45000'
                ? ($e->errorInfo[2] ?? $e->getMessage())
                : 'Error al finalizar el viaje.';
            error_log("sp_finalizar_viaje — " . $e->getMessage());
            header('Location: /logitrack/views/chofer/dashboard.php?error=' . urlencode($msg));
        }
        exit;
    }

    public function confirmarRecepcion(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /logitrack/views/chofer/dashboard.php');
            exit;
        }

        $nroTracking = trim($_POST['id_envio'] ?? '');
        if (empty($nroTracking)) {
            header('Location: /logitrack/views/chofer/dashboard.php?error=' . urlencode('Número de tracking inválido.'));
            exit;
        }

        $chofer = $this->choferModel->getPerfil($_SESSION['usuario_id']);
        if (!$chofer) {
            header('Location: /logitrack/views/chofer/dashboard.php?error=' . urlencode('Perfil de chofer no encontrado.'));
            exit;
        }

        // Verificar que el envío pertenece a un viaje del chofer y obtener id_suc_destino
        $stmt = $this->pdo->prepare("
            SELECT e.nro_tracking, e.id_suc_destino
            FROM   viaje_envio ve
            JOIN   viaje       v  ON ve.id_viaje  = v.id_viaje
            JOIN   envio       e  ON ve.id_envio  = e.nro_tracking
            WHERE  ve.id_envio  = :nro_tracking
              AND  v.id_chofer  = :id_chofer
            LIMIT  1
        ");
        $stmt->bindValue(':nro_tracking', $nroTracking,          PDO::PARAM_STR);
        $stmt->bindValue(':id_chofer',    $chofer['id_chofer'],  PDO::PARAM_STR);
        $stmt->execute();
        $envio = $stmt->fetch();

        if (!$envio) {
            header('Location: /logitrack/views/chofer/dashboard.php?error=' . urlencode('No tenés permiso para marcar este envío como entregado.'));
            exit;
        }

        try {
            $this->envioModel->confirmarRecepcion($nroTracking, $envio['id_suc_destino']);
            header('Location: /logitrack/views/chofer/dashboard.php?ok=' . urlencode('Envío marcado como entregado.'));
        } catch (\Exception $e) {
            error_log("ChoferController::confirmarRecepcion — " . $e->getMessage());
            header('Location: /logitrack/views/chofer/dashboard.php?error=' . urlencode($e->getMessage()));
        }
        exit;
    }
}

// ─── Punto de entrada directo (POST desde formularios) ────────────────────────
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'])) {
    require_once __DIR__ . '/../config/db.php';
    require_once __DIR__ . '/../middleware/auth.php';
    requireRol(['chofer']);

    $ctrl   = new ChoferController($pdo);
    $action = $_GET['action'] ?? '';

    if ($action === 'confirmarRecepcion') {
        $ctrl->confirmarRecepcion();
    } elseif ($action === 'finalizarViaje') {
        $ctrl->finalizarViaje();
    } else {
        header('Location: /logitrack/views/chofer/dashboard.php');
        exit;
    }
}
