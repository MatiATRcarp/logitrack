<?php
require_once __DIR__ . '/../../middleware/auth.php';
requireRol(['admin']);
require_once __DIR__ . '/../../config/db.php';

$resultados = null;
$errores    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirmar'] ?? '') === '1') {
    try {
        $sucursales = $pdo->query("SELECT id_sucursal FROM sucursal ORDER BY id_sucursal")->fetchAll(PDO::FETCH_COLUMN);
        if (empty($sucursales)) throw new Exception("No hay sucursales en la base de datos.");

        $idRolEmpleado = $pdo->query("SELECT id_rol FROM rol WHERE nombre='empleado' LIMIT 1")->fetchColumn();
        if (!$idRolEmpleado) throw new Exception("Rol 'empleado' no encontrado en la tabla rol.");

        $clave = password_hash('empleado123', PASSWORD_BCRYPT);

        $stmtEmp = $pdo->prepare("
            INSERT IGNORE INTO empleado (legajo, dni, nombre, apellido, id_sucursal, activo)
            VALUES (?, ?, ?, ?, ?, 1)
        ");
        $stmtUsr = $pdo->prepare("
            INSERT IGNORE INTO usuario (id_rol, dni, nombre, apellido, email, clave, id_empleado)
            VALUES (?, ?, ?, ?, ?, ?, (SELECT id_empleado FROM empleado WHERE dni = ? LIMIT 1))
        ");

        $nombres   = ['Santiago','Valentina','Mateo','Camila','Tomás','Martina','Joaquín','Sofía',
                      'Nicolás','Isabella','Lucas','Florencia','Benjamín','Lucía','Sebastián',
                      'Agustina','Emilio','Catalina','Franco','Micaela','Ignacio','Julieta',
                      'Rodrigo','Natalia','Andrés','Valeria','Diego','Paula','Hernán','Romina',
                      'Facundo','Gabriela','Leandro','Verónica','Mariano','Cecilia','Pablo',
                      'Alejandra','Gabriel','Laura','Carlos','Mónica','Jorge','Diana','Eduardo',
                      'Patricia','Gustavo','Claudia','Raúl','Norma','Marcelo','Stella','Hugo',
                      'Graciela','Alberto','Mirta','Enrique','Mónica','Oscar','Liliana','Daniel'];
        $apellidos = ['González','Rodríguez','Pérez','López','Martínez','García','Fernández',
                      'Sánchez','Torres','Díaz','Ramírez','Flores','Ruiz','Herrera','Morales',
                      'Castro','Vargas','Rojas','Álvarez','Jiménez','Romero','Navarro','Mendoza',
                      'Reyes','Cruz','Ortega','Medina','Vega','Ramos','Aguilar','Acosta','Cabrera',
                      'Gómez','Molina','Suárez','Silva','Serrano','Muñoz','Blanco','Guerrero'];

        $insertados   = 0;
        $dnisUsados   = [];
        $legajosUsados = [];

        for ($i = 1; $i <= 70; $i++) {
            $legajo = sprintf('EMP-%04d', 3000 + $i);
            if (in_array($legajo, $legajosUsados)) continue;

            // Generar DNI único de 8 dígitos
            do {
                $dni = (string) rand(30000000, 49999999);
            } while (in_array($dni, $dnisUsados));

            $nombre   = $nombres[array_rand($nombres)];
            $apellido = $apellidos[array_rand($apellidos)];
            $sucursal = $sucursales[$i % count($sucursales)];
            $email    = strtolower($nombre . '.' . $apellido . $i . '@logitrack.com');
            // Remove accents for email
            $email = strtr($email, ['á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u',
                                    'Á'=>'a','É'=>'e','Í'=>'i','Ó'=>'o','Ú'=>'u',
                                    'ñ'=>'n','Ñ'=>'n']);

            $stmtEmp->execute([$legajo, $dni, $nombre, $apellido, $sucursal]);
            if ($stmtEmp->rowCount() === 0) continue; // dni duplicado

            $stmtUsr->execute([$idRolEmpleado, $dni, $nombre, $apellido, $email, $clave, $dni]);

            $dnisUsados[]    = $dni;
            $legajosUsados[] = $legajo;
            $insertados++;
        }

        $resultados = ['empleados' => $insertados];

    } catch (Exception $e) {
        $errores[] = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Logitrack — Seeder Empleados</title>
    <link rel="stylesheet" href="/logitrack/public/css/style.css?v=<?= filemtime(__DIR__ . '/../../public/css/style.css') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/../layout/sidebar.php'; ?>
    <main class="main-content">

        <div class="topbar">
            <div>
                <h1 class="page-title">SEEDER EMPLEADOS</h1>
                <p class="page-subtitle">Genera 70 empleados de prueba</p>
            </div>
            <a href="/logitrack/views/admin/dashboard.php" class="btn btn-secondary">← Dashboard</a>
        </div>

        <?php if ($resultados): ?>
        <div class="alert alert-success" style="max-width:560px;margin-bottom:24px;">
            ✅ <?= $resultados['empleados'] ?> empleados insertados correctamente.<br>
            <small style="color:var(--gris);">Legajos EMP-3001 → EMP-3070 · Contraseña: <code>empleado123</code></small>
        </div>
        <a href="/logitrack/views/admin/empleados.php" class="btn btn-primary">Ver Empleados</a>

        <?php elseif (!empty($errores)): ?>
        <div class="alert alert-error" style="max-width:560px;">
            <?php foreach ($errores as $err): ?>
            <div>❌ <?= htmlspecialchars($err) ?></div>
            <?php endforeach; ?>
        </div>

        <?php else: ?>
        <div class="form-card" style="max-width:520px;">
            <p style="margin-bottom:20px;line-height:1.7;">
                Este seeder insertará:<br>
                &nbsp;&nbsp;• <strong>70 empleados</strong> distribuidos en todas las sucursales<br>
                &nbsp;&nbsp;• Un usuario por empleado con contraseña <code>empleado123</code><br>
                &nbsp;&nbsp;• Legajos numerados <code>EMP-3001</code> a <code>EMP-3070</code><br><br>
                <span style="color:#f87171;">⚠ Ejecutalo una sola vez. Los DNIs son aleatorios.</span>
            </p>
            <form method="POST">
                <input type="hidden" name="confirmar" value="1">
                <button type="submit" class="btn btn-primary" style="width:100%;height:50px;font-size:15px;letter-spacing:2px;">
                    ▶ GENERAR EMPLEADOS
                </button>
            </form>
        </div>
        <?php endif; ?>

    </main>
</div>
</body>
</html>
