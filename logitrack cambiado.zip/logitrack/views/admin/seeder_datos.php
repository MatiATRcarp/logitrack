<?php
require_once __DIR__ . '/../../middleware/auth.php';
requireRol(['admin']);
require_once __DIR__ . '/../../config/db.php';

$resultados = null;
$errores    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirmar'] ?? '') === '1') {

    try {
        // ── Obtener datos existentes ─────────────────────────────────────────
        $clientes = $pdo->query("SELECT dni FROM cliente ORDER BY RAND() LIMIT 200")->fetchAll(PDO::FETCH_COLUMN);
        if (count($clientes) < 2) throw new Exception("No hay suficientes clientes en la base de datos.");

        $tiposContenido = $pdo->query("SELECT nombre FROM tipo_contenido")->fetchAll(PDO::FETCH_COLUMN);
        if (empty($tiposContenido)) throw new Exception("No hay tipos de contenido.");

        $sucursales = $pdo->query("SELECT id_sucursal FROM sucursal")->fetchAll(PDO::FETCH_COLUMN);
        if (empty($sucursales)) throw new Exception("No hay sucursales.");

        $estados = $pdo->query("SELECT nombre, id_estado FROM tipo_estado")->fetchAll(PDO::FETCH_KEY_PAIR);
        $idPendiente   = $estados['Pendiente']   ?? null;
        $idEnTransito  = $estados['En tránsito'] ?? $estados['En Tránsito'] ?? null;
        if (!$idPendiente || !$idEnTransito) throw new Exception("Faltan tipo_estados: 'Pendiente' y/o 'En tránsito'.");

        // Choferes por tipo de licencia
        $licenciasEspeciales = ['E1', 'E2', 'E3', 'C2'];
        $listIn = implode("','", $licenciasEspeciales);
        $chofNormal   = $pdo->query("SELECT dni FROM chofer WHERE tipo_licencia NOT IN ('$listIn') AND tipo_licencia IS NOT NULL LIMIT 300")->fetchAll(PDO::FETCH_COLUMN);
        $chofEspecial = $pdo->query("SELECT dni FROM chofer WHERE tipo_licencia IN ('$listIn') LIMIT 300")->fetchAll(PDO::FETCH_COLUMN);
        $todosChoferes = array_merge($chofNormal, $chofEspecial);
        if (empty($todosChoferes)) throw new Exception("No hay choferes disponibles.");

        // Vehículos por tipo
        $vehNormal   = $pdo->query("SELECT v.patente FROM vehiculo v JOIN tipo_vehiculo tv ON v.id_tipo_veh = tv.nombre WHERE tv.requiere_licencia_especial = 0")->fetchAll(PDO::FETCH_COLUMN);
        $vehEspecial = $pdo->query("SELECT v.patente FROM vehiculo v JOIN tipo_vehiculo tv ON v.id_tipo_veh = tv.nombre WHERE tv.requiere_licencia_especial = 1")->fetchAll(PDO::FETCH_COLUMN);
        $todosVehiculos = array_merge($vehNormal, $vehEspecial);
        if (empty($todosVehiculos)) throw new Exception("No hay vehículos disponibles.");

        // ── Insertar 130 envíos para junio 2026 ─────────────────────────────
        $enviosPool = [];
        $stmtEnvio = $pdo->prepare("
            INSERT INTO envio (nro_tracking, fecha_recepcion, peso_kg, id_tipo_cont, id_remitente, id_destinatario, id_suc_origen, id_suc_destino)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmtHist = $pdo->prepare("
            INSERT INTO historial_estado (id_envio, id_estado, fecha_hora, id_sucursal_actual)
            VALUES (?, ?, ?, ?)
        ");

        $enviosCreados = 0;
        $intentos      = 0;
        while ($enviosCreados < 130 && $intentos < 300) {
            $intentos++;
            $nro = 'TRK-' . strtoupper(substr(md5(uniqid((string)rand(), true)), 0, 8));

            $existe = $pdo->prepare("SELECT COUNT(*) FROM envio WHERE nro_tracking = ?");
            $existe->execute([$nro]);
            if ((int)$existe->fetchColumn() > 0) continue;

            $rem  = $clientes[array_rand($clientes)];
            $dest = $clientes[array_rand($clientes)];
            $tries = 0;
            while ($dest === $rem && $tries++ < 10) $dest = $clientes[array_rand($clientes)];
            if ($dest === $rem) continue;

            $tipo   = $tiposContenido[array_rand($tiposContenido)];
            $sucOri = $sucursales[array_rand($sucursales)];
            $sucDes = $sucursales[array_rand($sucursales)];
            $tries  = 0;
            while ($sucDes === $sucOri && $tries++ < 10) $sucDes = $sucursales[array_rand($sucursales)];
            if ($sucDes === $sucOri) continue;

            // Random day in June 2026
            $dia    = rand(1, 29);
            $hora   = sprintf('%02d:%02d:00', rand(7, 21), rand(0, 59));
            $fecha  = sprintf('2026-06-%02d %s', $dia, $hora);
            $peso   = round(0.5 + (lcg_value() * 599.5), 2);

            $stmtEnvio->execute([$nro, $fecha, $peso, $tipo, $rem, $dest, $sucOri, $sucDes]);
            $stmtHist->execute([$nro, $idPendiente, $fecha, $sucOri]);
            $enviosPool[] = ['nro' => $nro, 'suc_orig' => $sucOri];
            $enviosCreados++;
        }

        // ── Insertar 75 viajes activos (en ruta ahora) ───────────────────────
        $stmtViaje = $pdo->prepare("
            INSERT INTO viaje (id_chofer, patente, fecha_salida, fecha_llegada_est)
            VALUES (?, ?, ?, ?)
        ");
        $stmtVE = $pdo->prepare("INSERT INTO viaje_envio (id_viaje, id_envio) VALUES (?, ?)");
        $stmtTr = $pdo->prepare("
            INSERT INTO historial_estado (id_envio, id_estado, fecha_hora, id_sucursal_actual)
            VALUES (?, ?, ?, ?)
        ");

        $viajesCreados = 0;
        $usedChoferes  = [];

        for ($i = 0; $i < 75; $i++) {
            // Pick chofer not already used
            $candidatos = array_diff($todosChoferes, $usedChoferes);
            if (empty($candidatos)) break;
            $candidatos = array_values($candidatos);
            $choferDni  = $candidatos[array_rand($candidatos)];
            $usedChoferes[] = $choferDni;

            // Pick compatible vehicle
            $esEspecial = in_array($choferDni, $chofEspecial);
            if ($esEspecial && !empty($vehEspecial) && rand(0, 1)) {
                $patente = $vehEspecial[array_rand($vehEspecial)];
            } elseif (!empty($vehNormal)) {
                $patente = $vehNormal[array_rand($vehNormal)];
            } else {
                $patente = $todosVehiculos[array_rand($todosVehiculos)];
            }

            // Salida: 1-10 días atrás; llegada: 5-30 días en el futuro
            $diasAtras    = rand(1, 10);
            $diasAdelante = rand(5, 30);
            $minutos      = rand(0, 1439);
            $salida  = date('Y-m-d H:i:s', mktime(intdiv($minutos, 60), $minutos % 60, 0) + strtotime("-$diasAtras days 00:00:00"));
            $llegada = date('Y-m-d H:i:s', mktime(intdiv($minutos, 60) + rand(0, 5), $minutos % 60, 0) + strtotime("+$diasAdelante days 00:00:00"));

            $stmtViaje->execute([$choferDni, $patente, $salida, $llegada]);
            $viajeId = (int) $pdo->lastInsertId();

            // Asignar 1-4 envíos del pool a este viaje
            $numEnvios = min(rand(1, 4), count($enviosPool));
            for ($j = 0; $j < $numEnvios; $j++) {
                if (empty($enviosPool)) break;
                $idx   = array_rand($enviosPool);
                $envio = $enviosPool[$idx];
                array_splice($enviosPool, $idx, 1);

                $stmtVE->execute([$viajeId, $envio['nro']]);
                $stmtTr->execute([$envio['nro'], $idEnTransito, $salida, $envio['suc_orig']]);
            }
            $viajesCreados++;
        }

        $resultados = [
            'envios'  => $enviosCreados,
            'viajes'  => $viajesCreados,
        ];

    } catch (Exception $e) {
        $errores[] = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Logitrack — Seeder de datos</title>
    <link rel="stylesheet" href="/logitrack/public/css/style.css?v=<?= filemtime(__DIR__ . '/../../public/css/style.css') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/../layout/sidebar.php'; ?>
    <main class="main-content">

        <div class="topbar">
            <div>
                <h1 class="page-title">SEEDER DE DATOS</h1>
                <p class="page-subtitle">Genera envíos y viajes de prueba</p>
            </div>
            <a href="/logitrack/views/admin/dashboard.php" class="btn btn-secondary">← Dashboard</a>
        </div>

        <?php if ($resultados): ?>
        <div class="alert alert-success" style="max-width:560px;margin-bottom:24px;">
            ✅ Datos generados correctamente:<br>
            &nbsp;&nbsp;• <?= $resultados['envios'] ?> envíos insertados (junio 2026)<br>
            &nbsp;&nbsp;• <?= $resultados['viajes'] ?> viajes activos creados (en ruta ahora)
        </div>
        <a href="/logitrack/views/admin/dashboard.php" class="btn btn-primary">Ver Dashboard</a>
        <a href="/logitrack/views/admin/mapa_tracking.php" class="btn btn-secondary" style="margin-left:12px;">Ver Mapa</a>

        <?php elseif (!empty($errores)): ?>
        <div class="alert alert-error" style="max-width:560px;">
            <?php foreach ($errores as $err): ?>
            <div>❌ <?= htmlspecialchars($err) ?></div>
            <?php endforeach; ?>
        </div>

        <?php else: ?>
        <div class="form-card" style="max-width:520px;">
            <p style="margin-bottom:20px;line-height:1.7;">
                Este seeder insertará:<br>
                &nbsp;&nbsp;• <strong>~130 envíos</strong> con fecha de junio 2026<br>
                &nbsp;&nbsp;• <strong>~75 viajes activos</strong> (en ruta ahora mismo, visibles en el mapa)<br>
                &nbsp;&nbsp;• Respetando compatibilidad de licencias y vehículos<br><br>
                <span style="color:#f87171;">⚠ Ejecutalo una sola vez. Correrlo de nuevo duplicará los datos.</span>
            </p>
            <form method="POST">
                <input type="hidden" name="confirmar" value="1">
                <button type="submit" class="btn btn-primary" style="width:100%;height:50px;font-size:15px;letter-spacing:2px;">
                    ▶ GENERAR DATOS DE PRUEBA
                </button>
            </form>
        </div>
        <?php endif; ?>

    </main>
</div>
</body>
</html>
