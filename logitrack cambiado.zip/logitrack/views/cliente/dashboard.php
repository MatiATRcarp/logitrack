<?php
require_once __DIR__ . '/../../middleware/auth.php';
requireRol(['cliente']);
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../controllers/ClienteController.php';

$controller = new ClienteController($pdo);
$data       = $controller->getDashboardData($_SESSION['usuario_id']);
$cliente    = $data['cliente'];
$enviados   = $data['enviados'];

$flash_msg  = $_SESSION['flash_msg']  ?? '';
$flash_tipo = $_SESSION['flash_tipo'] ?? 'success';
unset($_SESSION['flash_msg'], $_SESSION['flash_tipo']);

function badgeEstado(string $estado): string {
    return match($estado) {
        'Entregado' => 'badge-entregado',
        'En tránsito' => 'badge-transito',
        'Pendiente', 'Ingresado en sucursal destino' => 'badge-activo',
        'Cancelado', 'Con incidencias', 'Devuelto al remitente' => 'badge-inactivo',
        default => 'badge-inactivo'
    };
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logitrack — Mis Envíos</title>
    <link rel="stylesheet" href="/logitrack/public/css/style.css?v=<?= filemtime(__DIR__ . '/../../public/css/style.css') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        .btn-cancelar {
            padding: 4px 12px;
            font-size: 12px;
            border-radius: 8px;
            border: 1px solid #f87171;
            background: rgba(248,113,113,.08);
            color: #f87171;
            cursor: pointer;
            font-family: inherit;
            letter-spacing: 1px;
            transition: background .15s, color .15s;
            white-space: nowrap;
        }
        .btn-cancelar:hover { background: #f87171; color: #fff; }
    </style>
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/../layout/sidebar.php'; ?>
    <main class="main-content">

        <div class="topbar">
            <div>
                <h1 class="page-title">MIS ENVÍOS</h1>
                <p class="page-subtitle">Historial de paquetes enviados</p>
            </div>
        </div>

        <?php if ($flash_msg): ?>
        <div class="alert alert-<?= $flash_tipo === 'success' ? 'success' : 'error' ?>" style="max-width:700px;margin-bottom:20px;">
            <?= htmlspecialchars($flash_msg) ?>
        </div>
        <?php endif; ?>

        <?php if (!$cliente): ?>
            <div class="alert alert-error">No se encontró tu perfil de cliente vinculado a esta cuenta.</div>
        <?php else: ?>

        <div class="tabla-wrapper">
            <div class="tabla-header">
                <h3>📤 Envíos Realizados</h3>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Tracking</th>
                        <th>Destinatario</th>
                        <th>Destino</th>
                        <th>Peso</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Rastrear</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($enviados as $e): ?>
                    <tr>
                        <td><code><?= htmlspecialchars($e['nro_tracking']) ?></code></td>
                        <td><?= htmlspecialchars($e['dest_nombre'] . ' ' . $e['dest_apellido']) ?></td>
                        <td><?= htmlspecialchars($e['sucursal_destino']) ?></td>
                        <td><?= $e['peso_kg'] ?> kg</td>
                        <td><?= date('d/m/Y', strtotime($e['fecha_recepcion'])) ?></td>
                        <td>
                            <span class="badge <?= badgeEstado($e['estado']) ?>">
                                <?= htmlspecialchars($e['estado']) ?>
                            </span>
                        </td>
                        <td>
                            <a href="/logitrack/views/cliente/tracking.php?nro=<?= urlencode($e['nro_tracking']) ?>"
                               class="btn btn-secondary btn-sm">🔍 Ver</a>
                        </td>
                        <td>
                            <?php if ($e['estado'] === 'Pendiente' && !$e['en_viaje']): ?>
                            <a href="#cancel-<?= htmlspecialchars($e['nro_tracking']) ?>" class="btn-cancelar">
                                ✕ Cancelar
                            </a>
                            <!-- Modal de confirmación -->
                            <div class="modal-overlay" id="cancel-<?= htmlspecialchars($e['nro_tracking']) ?>">
                                <div class="modal-box">
                                    <p style="margin-bottom:16px;">
                                        ¿Cancelar el envío <strong><?= htmlspecialchars($e['nro_tracking']) ?></strong>?<br>
                                        <span style="color:var(--gris);font-size:13px;">Esta acción no se puede deshacer. El pedido quedará registrado como cancelado.</span>
                                    </p>
                                    <div class="modal-actions">
                                        <a href="#" class="btn btn-secondary">No, volver</a>
                                        <form method="POST" action="/logitrack/controllers/ClienteController.php?action=cancelarEnvio" style="margin:0;">
                                            <input type="hidden" name="nro_tracking" value="<?= htmlspecialchars($e['nro_tracking']) ?>">
                                            <button type="submit" class="btn-cancelar" style="padding:8px 20px;">Sí, cancelar pedido</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <span style="color:var(--gris);font-size:12px;">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($enviados)): ?>
                    <tr><td colspan="8" style="text-align:center;color:var(--gris);padding:32px;">Sin envíos registrados</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php endif; ?>
    </main>
</div>
</body>
</html>
