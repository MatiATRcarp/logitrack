<?php
require_once __DIR__ . '/../../middleware/auth.php';
requireRol(['chofer']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logitrack — Mi Posición en Mapa</title>
    <link rel="stylesheet" href="/logitrack/public/css/style.css?v=<?= filemtime(__DIR__ . '/../../public/css/style.css') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
    <style>
        #map-chofer {
            width: 100%;
            height: calc(100vh - 220px);
            min-height: 420px;
            border-radius: 16px;
            border: 1px solid var(--borde);
            background: #111;
            z-index: 1;
        }
        .info-viaje {
            background: var(--panel);
            border: 1px solid var(--borde);
            border-radius: 14px;
            padding: 18px 22px;
            margin-bottom: 18px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: center;
        }
        .info-dato { flex: 1 1 140px; }
        .info-dato .key { color: var(--gris); font-size: 11px; letter-spacing: 1px; text-transform: uppercase; }
        .info-dato .val { font-size: 16px; font-weight: 500; margin-top: 3px; }
        .progress-wrap { flex: 1 1 100%; }
        .progress-bar-bg {
            background: var(--borde); border-radius: 8px; height: 8px; overflow: hidden; margin-top: 6px;
        }
        .progress-bar-fill {
            height: 100%; border-radius: 8px; background: var(--amarillo);
            transition: width 1s ease;
        }
        .progress-bar-fill.completo { background: #6b7280; }
        .refresh-label { font-size: 12px; color: var(--gris); }
        .sin-viaje { color: var(--gris); font-size: 15px; padding: 32px 0; }
    </style>
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/../layout/sidebar.php'; ?>
    <main class="main-content">

        <div class="topbar">
            <div>
                <h1 class="page-title">MI POSICIÓN EN MAPA</h1>
                <p class="page-subtitle">Posición en tiempo real de tu viaje activo</p>
            </div>
            <span class="refresh-label" id="lbl-refresh">Cargando...</span>
        </div>

        <div id="panel-viaje">
            <div class="sin-viaje">Cargando datos del viaje...</div>
        </div>

        <div id="map-chofer"></div>

    </main>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const API_URL    = '/logitrack/api/tracking.php?chofer=1';
const REFRESH_MS = 30000;

const map = L.map('map-chofer').setView([-38.4161, -63.6167], 5);

L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '© OpenStreetMap, © CARTO',
    subdomains: 'abcd',
    maxZoom: 18
}).addTo(map);

const iconCamion = L.divIcon({
    html: '<div style="font-size:32px;line-height:1;filter:drop-shadow(0 0 6px #facc15);">🚛</div>',
    className: '',
    iconAnchor: [16, 16]
});
const iconOrigen = L.divIcon({
    html: '<div style="width:14px;height:14px;background:#22c55e;border-radius:50%;border:3px solid #fff;box-shadow:0 0 6px #22c55e;"></div>',
    className: '',
    iconAnchor: [7, 7]
});
const iconDestino = L.divIcon({
    html: '<div style="width:14px;height:14px;background:#ef4444;border-radius:50%;border:3px solid #fff;box-shadow:0 0 6px #ef4444;"></div>',
    className: '',
    iconAnchor: [7, 7]
});

let markerCamion = null;
let markerOrigen = null;
let markerDestino = null;
let lineaRuta = null;
let viajeActual = null;

function formatFecha(str) {
    if (!str) return '—';
    const d = new Date(str.replace(' ', 'T'));
    return d.toLocaleDateString('es-AR') + ' ' + d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
}

function renderViaje(v) {
    const pct      = Math.min(100, v.progreso_pct);
    const terminado = pct >= 100;
    const panel    = document.getElementById('panel-viaje');

    panel.innerHTML = `
    <div class="info-viaje">
        <div class="info-dato">
            <div class="key">Viaje</div>
            <div class="val" style="color:var(--amarillo);font-family:'Bebas Neue',sans-serif;font-size:22px;">#${v.id_viaje}</div>
        </div>
        <div class="info-dato">
            <div class="key">Patente</div>
            <div class="val"><code>${v.patente}</code></div>
        </div>
        <div class="info-dato">
            <div class="key">Origen</div>
            <div class="val">${v.sucursal_origen}</div>
        </div>
        <div class="info-dato">
            <div class="key">Destino</div>
            <div class="val">${v.sucursal_destino}</div>
        </div>
        <div class="info-dato">
            <div class="key">Salida</div>
            <div class="val">${formatFecha(v.fecha_salida)}</div>
        </div>
        <div class="info-dato">
            <div class="key">Llegada Estimada</div>
            <div class="val">${formatFecha(v.fecha_llegada_est)}</div>
        </div>
        <div class="info-dato">
            <div class="key">Paquetes a bordo</div>
            <div class="val">${v.total_paquetes}</div>
        </div>
        <div class="progress-wrap">
            <div class="key">Progreso del recorrido</div>
            <div class="progress-bar-bg">
                <div class="progress-bar-fill ${terminado ? 'completo' : ''}" style="width:${pct}%"></div>
            </div>
            <div style="font-size:13px;color:var(--gris);margin-top:4px;">
                ${terminado ? 'Llegaste a destino' : pct.toFixed(1) + '% completado'}
            </div>
        </div>
    </div>`;

    if (!v.tiene_coords) return;

    // Actualizar marcadores en el mapa
    if (!markerOrigen) {
        markerOrigen  = L.marker([v.lat_origen,  v.lng_origen],  { icon: iconOrigen  }).addTo(map)
            .bindPopup(`<b>🟢 ${v.sucursal_origen}</b><br>Punto de partida`);
        markerDestino = L.marker([v.lat_destino, v.lng_destino], { icon: iconDestino }).addTo(map)
            .bindPopup(`<b>🔴 ${v.sucursal_destino}</b><br>Destino`);
        lineaRuta     = L.polyline(
            [[v.lat_origen, v.lng_origen], [v.lat_destino, v.lng_destino]],
            { color: '#facc15', weight: 3, dashArray: '8 6', opacity: 0.6 }
        ).addTo(map);
        map.fitBounds([[v.lat_origen, v.lng_origen], [v.lat_destino, v.lng_destino]], { padding: [60, 60] });
    }

    const newLatLng = [v.lat_actual, v.lng_actual];
    if (!markerCamion) {
        markerCamion = L.marker(newLatLng, { icon: iconCamion }).addTo(map)
            .bindPopup(`<b>Tu posición actual</b><br>${pct.toFixed(1)}% del recorrido`);
    } else {
        markerCamion.setLatLng(newLatLng);
        markerCamion.getPopup()?.setContent(`<b>Tu posición actual</b><br>${pct.toFixed(1)}% del recorrido`);
    }

    if (viajeActual !== v.id_viaje) {
        viajeActual = v.id_viaje;
        map.setView(newLatLng, 8, { animate: true });
    }
}

function renderSinViaje() {
    document.getElementById('panel-viaje').innerHTML =
        '<div class="sin-viaje">No tenés un viaje activo en este momento. Cuando te asignen uno, aparecerá aquí.</div>';

    if (markerCamion)  { map.removeLayer(markerCamion);  markerCamion  = null; }
    if (markerOrigen)  { map.removeLayer(markerOrigen);  markerOrigen  = null; }
    if (markerDestino) { map.removeLayer(markerDestino); markerDestino = null; }
    if (lineaRuta)     { map.removeLayer(lineaRuta);     lineaRuta     = null; }
    viajeActual = null;
}

async function cargar() {
    try {
        const res  = await fetch(API_URL);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();

        if (data.length === 0) {
            renderSinViaje();
        } else {
            renderViaje(data[0]);
        }

        const ahora = new Date();
        document.getElementById('lbl-refresh').textContent =
            'Actualizado: ' + ahora.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch (e) {
        console.error('Error cargando tracking:', e);
        document.getElementById('lbl-refresh').textContent = 'Error de conexión. Reintentando...';
    }
}

cargar();
setInterval(cargar, REFRESH_MS);
</script>
</body>
</html>
